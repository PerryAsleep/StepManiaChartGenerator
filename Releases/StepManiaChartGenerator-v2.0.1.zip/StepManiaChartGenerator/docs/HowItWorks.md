# How It Works

## PadData and StepGraphs

The application understands how the dance pads are laid out based on [PadData](StepManiaLibrary/PadData.md) files. It understands how to perform moves on a pad through [StepGraphs](StepManiaLibrary/StepGraphs.md) that define how each [StepType](StepManiaLibrary/StepTypes.md) can move between every valid position on the pads.

The application comes with [PadData](StepManiaLibrary/PadData.md) and [StepGraph](StepManiaLibrary/StepGraphs.md) files for the following [ChartTypes](StepManiaLibrary/ChartType.md), though more can be added using the [PadDataGenerator](https://github.com/PerryAsleep/PadDataGenerator) application.

```C#
dance_single
dance_double
dance_solo
dance_threepanel
pump_single
pump_halfdouble
pump_double
smx_beginner
smx_single
smx_dual
smx_full
```

## Configuration

The application's behavior can be controlled via a [Config](Config.md) file. The config file informs the application, among other things, where to read and write charts, what types of charts to use, and how to convert them. The application comes with a [StepManiaChartGeneratorConfig.json](../StepManiaChartGeneratorConfig.json) file with sensible defaults, but it should be updated before running to at least control where to read and write charts, and what types of charts to convert from and to.

## ExpressedCharts

When converting a chart, the application will load an input chart and then parse it into an [ExpressedChart](StepManiaLibrary/ExpressedChart.md), which represents how the body moves in order to satisfy the chart by defining movements in terms of their [StepTypes](StepManiaLibrary/StepTypes.md).

## PerformedCharts

Once the [ExpressedChart](StepManiaLibrary/ExpressedChart.md) has been determined, a [PerformedChart](StepManiaLibrary/PerformedChart.md) is generated for the output [ChartType](StepManiaLibrary/ChartType.md), which defines the best way to execute the [ExpressedChart](StepManiaLibrary/ExpressedChart.md) on the output [ChartType](StepManiaLibrary/ChartType.md) using specific arrows. This is then converted to a StepMania `sm` or `ssc` file and written back to disk.

## Visualizations

The application can optionally output `html` [Visualizations](Visualizations.md) of the [ExpressedChart](StepManiaLibrary/ExpressedChart.md) and the [PerformedChart](StepManiaLibrary/PerformedChart.md). This is primarily meant for debugging.
